package com.example.u_511.findsynonym;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class WordPairs {
    String firstWord, secondWord;

    public void setFirstWord(String firstWord){
        this.firstWord = firstWord;
    }

    public String getFirstWord() {
        return this.firstWord;
    }

    public void setSecondWord(String secondWord){
        this.secondWord = secondWord;
    }

    public String getSecondWord() {
        return this.secondWord;
    }
}
