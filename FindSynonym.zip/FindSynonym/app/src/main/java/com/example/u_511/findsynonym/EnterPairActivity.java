package com.example.u_511.findsynonym;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class EnterPairActivity extends AppCompatActivity {

    DatabaseHelper helper = new DatabaseHelper(this);

    public void enterHomeScreen(View view){
        Intent newActivity = new Intent(this, HomeActivity.class);
        startActivity(newActivity);

    }
    public void onEnterPairClick(View v){
        if(v.getId() == R.id.button_PairsToData){
            EditText firstWord = (EditText) findViewById(R.id.text_FirstWord);
            EditText secondWord = (EditText)findViewById(R.id.text_SecondWord);

            String fWord = firstWord.getText().toString();
            String sWord = secondWord.getText().toString();

            if(fWord.isEmpty() || sWord.isEmpty()){
                //popup message
                Toast wd = Toast.makeText(EnterPairActivity.this, "words can't empty", Toast.LENGTH_SHORT);
                wd.show();
            }
            else{
                //inset the details in database
                WordPairs wd = new WordPairs();
                wd.setFirstWord(fWord);
                wd.setSecondWord(sWord);

                helper.insertWordPairs(wd);

                Intent newActivity = new Intent(this, HomeActivity.class);
                startActivity(newActivity);
            }

        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_pair);
    }
}
