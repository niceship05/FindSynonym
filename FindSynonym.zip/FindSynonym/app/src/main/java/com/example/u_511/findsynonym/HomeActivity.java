package com.example.u_511.findsynonym;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.EditText;

public class HomeActivity extends AppCompatActivity {

    DatabaseHelper helper = new DatabaseHelper(this);
    public void enterPairScreen(View view){
        Intent newActivity = new Intent(this, EnterPairActivity.class);
        startActivity(newActivity);

    }

    public void resultScreen(View view){
        Intent newActivity = new Intent(this, resultActivity.class);
        startActivity(newActivity);

    }

    public void onClickFindWord(View v){
        if(v.getId() == R.id.button_findSynonym){
            EditText fw = (EditText)findViewById(R.id.enterText);
            String str = fw.getText().toString();
            int findWd = helper.findWord(str);
            String syn = helper.searchWord(str);

            if(findWd == 1) {
                Intent newActivity = new Intent(this, resultActivity.class);
                newActivity.putExtra("sy", syn);
                startActivity(newActivity);
            }

                else{
                    Intent newActivity = new Intent(this, resultActivity.class);
                    newActivity.putExtra("sy", "words not found");
                    startActivity(newActivity);
                }

        }

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }
}
