package com.example.u_511.findsynonym;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "wordPairs.db";
    private static final String TABLE_NAME = "wordPairs";
    private static final String FIRST_WORD = "firstWord";
    private static final String SECOND_WORD = "secondWord";
    SQLiteDatabase db;
    private static final String TABLE_CREATE = "create table wordPairs (firstWord text not null , " + "secondWord text not null)";

    public DatabaseHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
        this.db = db;
    }

    public void insertWordPairs(WordPairs wd){
        db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(FIRST_WORD, wd.getFirstWord());
        values.put(SECOND_WORD, wd.getSecondWord());

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public String searchWord(String firstWord){
        db = this.getReadableDatabase();
        String query = "select firstWord, secondWord from "+ TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);
        String wd;
        String syn = "word not found";
        if(cursor.moveToFirst()){
            do{
                wd = cursor.getString(0);
                syn = cursor.getString(1);
                if(wd.equals(firstWord)){
                    syn = cursor.getString(1);
                    break;
                }
            }
            while(cursor.moveToNext());


        }return syn;
    }

    public int findWord(String firstWord){
        db = this.getReadableDatabase();
        String query = "select firstWord, secondWord from "+ TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);
        String wd;
        int found = 0;
        if(cursor.moveToFirst()){
            do{
                wd = cursor.getString(0);

                if(wd.equals(firstWord)){
                    found = 1;
                    break;
                }
            }
            while(cursor.moveToNext());


        } return found;
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String query = "DROP TABLE IF EXISTS " + TABLE_NAME;
        db.execSQL(query);
        this.onCreate(db);
    }
}
